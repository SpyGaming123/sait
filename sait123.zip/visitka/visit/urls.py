from django.urls import path
from . import views

urlpatterns = [
    path('', views.main, name='main'),
    path('about_klass', views.about_klass, name='about_klass'),
]
